<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
                
        <?php echo $__env->make('includes.css_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldSection(); ?>

    </head>

    <!-- NAVBAR
    
    ================================================== -->

    <body>

        <div class="navbar-wrapper">
			<?php echo $__env->make('includes.menu_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldSection(); ?>  
        </div>    

        <!-- Carousel
    
        ================================================== -->

<div class="banner">

  <img src="<?php echo e(asset('public/assets/img/about_banner.jpg')); ?>" alt="..." class="img-responsive">

</div>

<div class="pencil-bg">

  <div class="container inr-page">

    <div class="col-sm-9 con-area">

      <h1 class="heading">

        About Us<br>

        <img src="<?php echo e(asset('public/assets/img/hed-sep.jpg')); ?>" alt="">

      </h1>

      <p>

       '<strong>Public Central School</strong>' Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam aliquam sed est sit amet scelerisque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Duis efficitur tempus luctus. Nulla eu dui pretium, consequat sapien vitae, vehicula lorem. Vivamus malesuada a felis non pretium. Cras a mauris in magna auctor pellentesque.Ut commodo

 sem eget velit feugiat mollis.Proin congue erat a dolor bibendum accumsan.

      </p>

      <p>

       Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam aliquam sed est sit amet scelerisque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Duis efficitur tempus luctus. Nulla eu dui pretium, consequat sapien vitae, vehicula lorem. Vivamus malesuada a felis non pretium. Cras a mauris in magna auctor pellentesque.Ut commodo

 sem eget velit feugiat mollis.Proin congue erat a dolor bibendum accumsan.<br>

<br>

Public Central School Convent School is an English Medium co-educational School, situated in Mariam Nagar, Ghaziabad, UP.

      </p>



      



      <p>&nbsp;

        

      </p>



     

    </div>

    <div class="col-sm-3">

      <div class="col-md-12" style="padding:0;">
			<?php echo $__env->make('includes.latest_news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldSection(); ?>
		</div>

  <div class="clearfix">&nbsp;</div>
  </div>
   <div class="clearfix">&nbsp;</div>
</div>

  </div>


            <!-- FOOTER -->

            <footer>
                <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->yieldSection(); ?>
            </footer>



        </div><!-- /.container -->
        
        <?php echo $__env->make('includes.js_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldSection(); ?>

    </body>

</html>