<h3>Latest News & Events</h3>
  <div class="vticker demof">
		<ul>
			<li><a href="#">PUBLIC CENTRAL SCHOO</a><p>NH. 322, Gandhi Chowk,
			Khalispur, Samastipur.<br>
			Form Distribution &amp; Registration From <strong>24th March</strong>.Last Date of Form Submission

			on <strong>28th March</strong>. Entrance Test on <strong>29th March</strong>. Result on <strong>30th March</strong>. Admission &amp;
			Book Distribution from <strong>1st April</strong>. Classes will begin from <strong>11th April</strong>.</p></li>

			<li class="odd"><a href="#">
			GYANDEEP PUBLIC SCHOOL</a><p>Vidyapati Nagar, Samastipur.<br>
			Issue of Information Broucher &amp; Application Form From <strong>27th January</strong>.Last Date
			of Form Submission on <strong>10th February</strong>. Entrance Test <strong>11th February</strong>, Venue SCHOOL
			CAMPUS. Result <strong>14th February</strong>. Admission from <strong>16th February</strong>. Distribution of
			Books from <strong>1st March</strong>. Classes will begin from <strong>16th March</strong>.</p>
			</li>

			<li class="odd"><a href="#">
			GYANDEEP PUBLIC SCHOOL</a><p>Vidyapati Nagar, Samastipur.<br>
			Issue of Information Broucher &amp; Application Form From <strong>27th January</strong>.Last Date
			of Form Submission on <strong>10th February</strong>. Entrance Test <strong>11th February</strong>, Venue SCHOOL
			CAMPUS. Result <strong>14th February</strong>. Admission from <strong>16th February</strong>. Distribution of
			Books from <strong>1st March</strong>. Classes will begin from <strong>16th March</strong>.</p>
			</li>

			<li class="odd"><a href="#">
			GYANDEEP PUBLIC SCHOOL</a><p>Vidyapati Nagar, Samastipur.<br>
			Issue of Information Broucher &amp; Application Form From <strong>27th January</strong>.Last Date
			of Form Submission on <strong>10th February</strong>. Entrance Test <strong>11th February</strong>, Venue SCHOOL
			CAMPUS. Result <strong>14th February</strong>. Admission from <strong>16th February</strong>. Distribution of
			Books from <strong>1st March</strong>. Classes will begin from <strong>16th March</strong>.</p>
			</li>

			<li style="margin: 0px; opacity: 0.139744;"><a href="#">DAFFODIL PREP. SCHOOL</a><p>Sarangpur, Gandhi Chowk,Khalispur, Samastipur. <br>Registration &amp; Admission From <strong>17th January</strong>. Books, Stationery &amp; Uniform.<br>
			Distribution from <strong>2nd February</strong>. Classes will begin from <strong>17th February</strong>.</p>
			</li>

			<li class="odd"><a href="#">GYANDEEP PUBLIC SCHOOL</a><p>Vidyapati Nagar, Samastipur.<br>
			Issue of Information Broucher &amp; Application Form From <strong>27th January</strong>.Last Date
			of Form Submission on <strong>10th February</strong>. Entrance Test <strong>11th February</strong>, Venue SCHOOL
			CAMPUS. Result <strong>14th February</strong>. Admission from <strong>16th February</strong>. Distribution of
			Books from <strong>1st March</strong>. Classes will begin from <strong>16th March</strong>.</p>
			</li>

		</ul>
	</div>