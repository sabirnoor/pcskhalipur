<!-- Footer Start -->
		<footer>
			<i class="fa fa-copyright" aria-hidden="true"></i> Tekoffice <span>2013-2017</span>
		</footer>
		<!-- Footer end -->