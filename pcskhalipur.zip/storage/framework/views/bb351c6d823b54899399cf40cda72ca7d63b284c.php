<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
                
        <?php echo $__env->make('includes.css_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldSection(); ?>

    </head>

    <!-- NAVBAR
    
    ================================================== -->

    <body>

        <div class="navbar-wrapper">
			<?php echo $__env->make('includes.menu_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldSection(); ?>  
        </div>    

        <!-- Carousel
    
        ================================================== -->

<div class="banner">

  <img src="<?php echo e(asset('public/assets/img/about_banner.jpg')); ?>" alt="..." class="img-responsive">

</div>

<div class="pencil-bg">

  <div class="container inr-page">

    <div class="col-sm-9 con-area">

      <h1 class="heading">

        School Profile<br>

        <img src="<?php echo e(asset('public/assets/img/hed-sep.jpg')); ?>" alt="">

      </h1>

      <div class="panel-group" id="accordion">

    <div class="panel panel-default">
      <div class="panel-heading">
        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
		<h4 class="panel-title">
            <i class="fa fa-plus"></i> CLASS III SYLLABUS
        </h4></a>
      </div>
      <div id="collapseOne" class="panel-collapse collapse in">
        <div class="panel-body">
			<div class="panel-body whbg table-responsive nopadding">
					 <div class="clearfix"></div>
	  
						<table class="responsive" width="100%">

                      <tr>
                        <!-- <th class="heading-tabl">Download Class Wise </th> -->
                        <th class="heading-tabl">Form Name</th>
                        <!-- <th class="heading-tabl">View </th> -->
                        <th class="heading-tabl" style="text-align:right;">Download <span class="caret"></span></th>
                      </tr>
                      <tr>
                        <td>COMPUTER SYLLABUS CLASS III</td>
                        <td align="right"><a href="<?php echo e(url('public/SYLLABUS-2018-2019/CLASS III SYLLABUS/COMPUTER SYLLABUS CLASS III.docx')); ?>" target="_blank" class="fa fa-download btn btn-primary right"></a></td>
                      </tr>
					  <tr>
                        <td>ENGLISH SYLLABUS CLASS III</td>
                        <td align="right"><a href="<?php echo e(url('public/SYLLABUS-2018-2019/CLASS III SYLLABUS/ENGLISH SYLLABUS class III.docx')); ?>" target="_blank" class="fa fa-download btn btn-primary right"></a></td>
                      </tr>
					  <tr>
                        <td>GENERAL KNOWLEDGE SYLLABUS CLASS III</td>
                        <td align="right"><a href="<?php echo e(url('public/SYLLABUS-2018-2019/CLASS III SYLLABUS/GENERAL KNOWLEDGE SYLLABUS CLASS III.docx')); ?>" target="_blank" class="fa fa-download btn btn-primary right"></a></td>
                      </tr>
					  <tr>
                        <td>MATHEMATICS SYLLABUS class III</td>
                        <td align="right"><a href="<?php echo e(url('public/SYLLABUS-2018-2019/CLASS III SYLLABUS/MATHEMATICS SYLLABUS class III.docx')); ?>" target="_blank" class="fa fa-download btn btn-primary right"></a></td>
                      </tr>
					  <tr>
                        <td>SCIENCE SYLLABUS CLASS III</td>
                        <td align="right"><a href="<?php echo e(url('public/SYLLABUS-2018-2019/CLASS III SYLLABUS/SCIENCE SYLLABUS CLASS III.docx')); ?>" target="_blank" class="fa fa-download btn btn-primary right"></a></td>
                      </tr>
					  <tr>
                        <td>SOCIAL SCIENCE SYLLABUS CLASS III</td>
                        <td align="right"><a href="<?php echo e(url('public/SYLLABUS-2018-2019/CLASS III SYLLABUS/SOCIAL SCIENCE SYLLABUS CLASS III.docx')); ?>" target="_blank" class="fa fa-download btn btn-primary right"></a></td>
                      </tr>
                    </table>
					<p>&nbsp;</p>
			</div>

        </div>
      </div>
    </div>
	
    <div class="panel panel-default">
      <div class="panel-heading">
        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"> <h4 class="panel-title">
            <i class="fa fa-plus"></i> CLASS IV SYLLABUS
        </h4></a>
      </div>
	  
      <div id="collapseTwo" class="panel-collapse collapse">
        <div class="panel-body">
          <div class="panel-body whbg table-responsive nopadding">
				<div class="clearfix"></div>
	 
						<table class="responsive" width="100%">
                      <tr>
                        <!-- <th class="heading-tabl">Download Class Wise </th> -->
                        <th class="heading-tabl">Form Name</th>
                        <!-- <th class="heading-tabl">View </th> -->
                        <th class="heading-tabl" style="text-align:right;">Download <span class="caret"></span></th>
                      </tr>
                      <tr>
                        <td>COMPUTER SYLLABUS CLASS IV</td>
                        <td align="right"><a href="<?php echo e(url('public/SYLLABUS-2018-2019/CLASS IV SYLLABUS/COMPUTER SYLLABUS CLASS IV.docx')); ?>" target="_blank" class="fa fa-download btn btn-primary right"></a></td>
                      </tr>
					  <tr>
                        <td>ENGLISH SYLLABUS CLASS IV</td>
                        <td align="right"><a href="<?php echo e(url('public/SYLLABUS-2018-2019/CLASS IV SYLLABUS/ENGLISH SYLLABUS CLASS IV.docx')); ?>" target="_blank" class="fa fa-download btn btn-primary right"></a></td>
                      </tr>
					  <tr>
                        <td>GENERAL KNOWLEDGE SYLLABUS CLASS IV</td>
                        <td align="right"><a href="<?php echo e(url('public/SYLLABUS-2018-2019/CLASS IV SYLLABUS/GENERAL KNOWLEDGE SYLLABUS CLASS IV.docx')); ?>" target="_blank" class="fa fa-download btn btn-primary right"></a></td>
                      </tr>
					  <tr>
                        <td>MATHEMATICS SYLLABUS CLASS IV</td>
                        <td align="right"><a href="<?php echo e(url('public/SYLLABUS-2018-2019/CLASS IV SYLLABUS/MATHEMATICS SYLLABUS class IV.docx')); ?>" target="_blank" class="fa fa-download btn btn-primary right"></a></td>
                      </tr>
					  <tr>
                        <td>SCIENCE SYLLABUS CLASS IV</td>
                        <td align="right"><a href="<?php echo e(url('public/SYLLABUS-2018-2019/CLASS IV SYLLABUS/CSCIENCE SYLLABUS CLASS IV.docx')); ?>" target="_blank" class="fa fa-download btn btn-primary right"></a></td>
                      </tr>
					  <tr>
                        <td>SOCIAL SCIENCE SYLLABUS CLASS IV</td>
                        <td align="right"><a href="<?php echo e(url('public/SYLLABUS-2018-2019/CLASS IV SYLLABUS/SOCIAL SCIENCE SYLLABUS CLASS IV.docx')); ?>" target="_blank" class="fa fa-download btn btn-primary right"></a></td>
                      </tr>
                    </table>
					<p>&nbsp;</p>
		  </div>

        </div>
      </div>
    </div>
	
	<div class="panel panel-default">
      <div class="panel-heading">
        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapsethree"> <h4 class="panel-title">
            <i class="fa fa-plus"></i> CLASS IX SYLLABUS
        </h4></a>
      </div>
	  
      <div id="collapsethree" class="panel-collapse collapse">
        <div class="panel-body">
          <div class="panel-body whbg table-responsive nopadding">
			----------
		  </div>

        </div>
      </div>
    </div>
	
	<div class="panel panel-default">
      <div class="panel-heading">
        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapsefour"> <h4 class="panel-title">
            <i class="fa fa-plus"></i> CLASS V SYLLABUS
        </h4></a>
      </div>
	  
      <div id="collapsefour" class="panel-collapse collapse">
        <div class="panel-body">
          <div class="panel-body whbg table-responsive nopadding">
			----------
		  </div>

        </div>
      </div>
    </div>
	
	<div class="panel panel-default">
      <div class="panel-heading">
        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapsefive"> <h4 class="panel-title">
            <i class="fa fa-plus"></i> CLASS VI SYLLABUS
        </h4></a>
      </div>
	  
      <div id="collapsefive" class="panel-collapse collapse">
        <div class="panel-body">
          <div class="panel-body whbg table-responsive nopadding">
			----------
		  </div>

        </div>
      </div>
    </div>
	
	<div class="panel panel-default">
      <div class="panel-heading">
        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapsesix"> <h4 class="panel-title">
            <i class="fa fa-plus"></i> CLASS VII SYLLABUS
        </h4></a>
      </div>
	  
      <div id="collapsesix" class="panel-collapse collapse">
        <div class="panel-body">
          <div class="panel-body whbg table-responsive nopadding">
			----------
		  </div>

        </div>
      </div>
    </div>
	
	<div class="panel panel-default">
      <div class="panel-heading">
        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseseven"> <h4 class="panel-title">
            <i class="fa fa-plus"></i> CLASS VIII SYLLABUS
        </h4></a>
      </div>
	  
      <div id="collapseseven" class="panel-collapse collapse">
        <div class="panel-body">
          <div class="panel-body whbg table-responsive nopadding">
			----------
		  </div>

        </div>
      </div>
    </div>
	
	<div class="panel panel-default">
      <div class="panel-heading">
        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseeight"> <h4 class="panel-title">
            <i class="fa fa-plus"></i> CLASS X SYLLABUS
        </h4></a>
      </div>
	  
      <div id="collapseeight" class="panel-collapse collapse">
        <div class="panel-body">
          <div class="panel-body whbg table-responsive nopadding">
			----------
		  </div>

        </div>
      </div>
    </div>
	
  </div>

    
    </div>

    <div class="col-sm-3">

      <div class="col-md-12" style="padding:0;">
			<?php echo $__env->make('includes.latest_news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldSection(); ?>
		</div>

  <div class="clearfix">&nbsp;</div>
  </div>
   <div class="clearfix">&nbsp;</div>
</div>

  </div>


            <!-- FOOTER -->

            <footer>
                <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->yieldSection(); ?>
            </footer>



        </div><!-- /.container -->
        
        <?php echo $__env->make('includes.js_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldSection(); ?>

    </body>

</html>