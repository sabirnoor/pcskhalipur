<?php 
//print_r($bustype);die;
?>
<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Tekoffice | B2B and B2C market place" />
<meta name="keywords" content="B2B and B2C market place, manage hotels, holidays package and flight" />
<meta name="author" content="Tekoffice" />
<title>Dashboard</title>
<?php echo $__env->make('includes.css_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	<?php echo $__env->yieldSection(); ?>
</head>

<body>

<!-- Header starts --> 
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	<?php echo $__env->yieldSection(); ?> 
<!-- Header ends --> 

<!-- Container fluid Starts -->
<div class="container-fluid"> 
  
  <!-- Navbar starts --> 
  <?php echo $__env->make('includes.menu_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldSection(); ?> 
  <!-- Navbar ends --> 
  
  <!-- Dashboard wrapper starts -->
  <div class="dashboard-wrapper"> 
    
    <!-- Top bar starts -->
    <div class="top-bar clearfix">
      <div class="row gutter">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <div class="page-title">
            <h4>Manage</h4>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <ul class="right-stats" id="mini-nav-right">
            <li> <a href="<?php echo e(url('manageroute')); ?>" class="btn btn-danger">Manage Route</a> </li>
            <li> <a href="<?php echo e(url('newroute')); ?>" class="btn btn-success">Create Route</a> </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- Top bar ends --> 
    
    <!-- Main container starts -->
    <div class="main-container">
      <div class="row gutter">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="panel panel-blue">
            <div class="panel-heading">
              <h4>Route List</h4>
            </div>
            <div class="panel-body">
              <div class="table-responsive">
                <table id="responsiveTable" class="table table-striped table-bordered no-margin" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>Service Name/No.</th>
                      <th>Bus Type</th>
                      <th>From City</th>
                      <th>To City</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  
                  <tbody>
                  <?php if($RoutesList): ?>
						<?php $__currentLoopData = $RoutesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($val->id); ?>">
                      <td><?php echo e($val->service_name); ?></td>
                      <td><?php echo e($val->vehicle); ?> <?php echo e($val->isac); ?> <?php echo e($val->bus_type); ?> (<?php echo e($val->layout_type); ?>)</td>
                      <td><?php echo e($val->fromcity_name); ?></td>
                      <td><?php echo e($val->tocity_name); ?></td>
                      <td>
                      <a href="<?php echo e(url('newroute/'.$val->id)); ?>" title="Update" class="text-success"><i class="fa fa-pencil-square-o fa-1x"></i></a>
						<a href="javascript::void(0);" title="Delete" id="<?php echo e($val->id); ?>" class="text-danger Deleteroute"><i class="fa fa-trash-o fa-1x"></i></a></td>
                    </tr>
                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>	
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Main container ends --> 
    
  </div>
  <!-- Dashboard Wrapper End --> 
  
</div>
<!-- Container fluid ends --> 

<?php echo $__env->make('includes.copy_right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	<?php echo $__env->yieldSection(); ?>

		<?php echo $__env->make('includes.js_common_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	<?php echo $__env->yieldSection(); ?> 
<script>
		$(document).ready(function(){
			$('.newcoach').click(function(){
				var page = $(this).attr("pg");
				
			});
			
			
		});
		</script>
</body>
</html>