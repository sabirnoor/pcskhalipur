<title> Public Central School</title>
<style>
.dropdown .dropdown-menu {

	-webkit-transition: all 0.3s;

	-moz-transition: all 0.3s;

	-ms-transition: all 0.3s;

	-o-transition: all 0.3s;

	transition: all 0.3s;

	max-height: 0;

	display: block;

	opacity: 0;

}
.dropdown:hover .dropdown-menu {

	max-height:inherit;

	opacity: 1;}

</style>
<link href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/assets/css/scss.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/assets/css/font-awesome.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/assets/css/lightgallery.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/globals.css')); ?>">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('public/assets/img/favicon-32x32.png')); ?>">



