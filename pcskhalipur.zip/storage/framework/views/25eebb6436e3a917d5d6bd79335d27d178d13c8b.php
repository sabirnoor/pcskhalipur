
 <style>
 ul li{ list-style:none;}
 </style>
 <ul>
 <li><h5>Boarding from <?php echo($result[0]->cityname);?></h5></li>
 <?php if($result): ?>
		<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($val->location); ?> &nbsp;&nbsp;<span style="float:right;"><?php echo e($val->bordingtime); ?></span></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>
</ul>


