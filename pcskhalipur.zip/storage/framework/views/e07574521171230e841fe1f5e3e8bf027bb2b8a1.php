<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
                
        <?php echo $__env->make('includes.css_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldSection(); ?>

    </head>

    <!-- NAVBAR
    
    ================================================== -->

    <body>

        <div class="navbar-wrapper">
			<?php echo $__env->make('includes.menu_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldSection(); ?>  
        </div>    

        <!-- Carousel
    
        ================================================== -->

<div class="banner">

  <img src="<?php echo e(asset('public/assets/img/about_banner.jpg')); ?>" alt="..." class="img-responsive">

</div>

<div class="pencil-bg">

  <div class="container inr-page">

    <div class="col-sm-9 con-area">

      <h1 class="heading">

        Result<br>

        <img src="<?php echo e(asset('public/assets/img/hed-sep.jpg')); ?>" alt="">

      </h1>
	  
	  <div class="clearfix"></div>
	  
      <table class="responsive" width="100%">

                      <tr>

                        <!-- <th class="heading-tabl">Download Class Wise </th> -->

                        <th class="heading-tabl">Result Name</th>

                        <!-- <th class="heading-tabl">View </th> -->

                        <th class="heading-tabl" style="text-align:right;">Download <span class="caret"></span></th>

   

                      </tr>

                      <tr>
                        <td>Entrance Exam Result 2019</td>
                        <td align="right"><a href="<?php echo e(url('public/assets/download_pdf/Entrance-Exam-Result-2019.pdf')); ?>" target="_blank" class="fa fa-download btn btn-primary right"></a></td>
                      </tr>
					  
                    </table>
					<p>&nbsp;</p>

    
    </div>

    <div class="col-sm-3">

      <div class="col-md-12" style="padding:0;">
			<?php echo $__env->make('includes.latest_news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldSection(); ?>
		</div>

  <div class="clearfix">&nbsp;</div>
  </div>
   <div class="clearfix">&nbsp;</div>
</div>

  </div>


            <!-- FOOTER -->

            <footer>
                <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->yieldSection(); ?>
            </footer>



        </div><!-- /.container -->
        
        <?php echo $__env->make('includes.js_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldSection(); ?>

    </body>

</html>