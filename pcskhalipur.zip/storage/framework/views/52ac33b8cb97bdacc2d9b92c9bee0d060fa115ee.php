<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
                
        <?php echo $__env->make('includes.css_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldSection(); ?>

    </head>

    <!-- NAVBAR
    
    ================================================== -->

    <body>

        <div class="navbar-wrapper">
			<?php echo $__env->make('includes.menu_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldSection(); ?>  
        </div>    

        <!-- Carousel
    
        ================================================== -->

<div class="banner">

  <img src="<?php echo e(asset('public/assets/img/about_banner.jpg')); ?>" alt="..." class="img-responsive">

</div>

<div class="pencil-bg">

  <div class="container inr-page">

    <div class="col-sm-9 con-area">

      <h1 class="heading">

        News Paper<br>

        <img src="<?php echo e(asset('public/assets/img/hed-sep.jpg')); ?>" alt="">

      </h1>

      <p><?php echo html_entity_decode($Staticcontent->contents)?></p>

    
    </div>

    <div class="col-sm-3">

      <div class="col-md-12" style="padding:0;">
			<?php echo $__env->make('includes.latest_news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldSection(); ?>
		</div>

  <div class="clearfix">&nbsp;</div>
  </div>
   <div class="clearfix">&nbsp;</div>
</div>

  </div>


            <!-- FOOTER -->

            <footer>
                <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->yieldSection(); ?>
            </footer>



        </div><!-- /.container -->
        
        <?php echo $__env->make('includes.js_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldSection(); ?>

    </body>

</html>