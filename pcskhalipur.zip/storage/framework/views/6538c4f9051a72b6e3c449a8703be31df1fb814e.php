<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
                
        <?php echo $__env->make('includes.css_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldSection(); ?>

    </head>

    <!-- NAVBAR
    
    ================================================== -->

    <body>

        <div class="navbar-wrapper">
			<?php echo $__env->make('includes.menu_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldSection(); ?>  
        </div>    

        <!-- Carousel
    
        ================================================== -->

        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

            <!-- Indicators -->

            <ol class="carousel-indicators">
			<?php
				if($UploadflashList){
					foreach($UploadflashList as $k=>$val){
			?>
                <li data-target="#carousel-example-generic" data-slide-to="<?=$k?>" class="<?=($k==0)?'active':''?>"></li>
			<?php 
					}
				}
				?>
                <!--<li data-target="#carousel-example-generic" data-slide-to="1"></li>-->

            </ol>



            <!-- Wrapper for slides -->

            <div class="carousel-inner" role="listbox">
			<?php
				if($UploadflashList){
					foreach($UploadflashList as $k=>$val){
			?>
                <div class="item <?=($k==0)?'active':''?>">
                    <img src="<?php echo e(img_src_path()); ?>uploadflash/<?php echo e($val['images']); ?>" alt="...">
                </div>
				<?php 
					}
				}
				?>
                
            </div>
            <!-- Controls -->

            <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>

        </div><!-- /.carousel -->





        <!-- notice board -->

        <div class="notice-board">

            <div class="container">

                <h1 class="heading">NOTICE 

                    BOARD</h1>

                <div class="slide-area">
                    <!-- Carousel================================================== -->
                    <div id="notice" class="carousel slide" data-ride="carousel">
                         <!-- Wrapper for slides -->
                         <div class="carousel-inner" role="listbox">
						 <?php if($Noticeboard){ foreach($Noticeboard as $k=>$val){ ?>
                            <div class="item <?php if($k==0){echo 'active';} ?>">
                                <h3><span>Date on: <?=date('d-M-Y',strtotime($val['noticedate']))?></span><?=trim($val['title'])?></h3>
                            </div>
						 <?php } } ?>
                            <!--<div class="item">
                                <h3><span>Updated on: 3th Apr, 2016</span>Nullam quis ex iaculis, blandit tellus in, tincidunt justo. Ut ex arcu.</h3>
                            </div>
                            <div class="item">
                                <h3><span>Updated on: 4th Apr, 2016</span>Nullam quis ex iaculis, blandit tellus in, tincidunt justo. Ut ex arcu.</h3>
                            </div>
                            <div class="item">
                                <h3><span>Updated on: 5th Apr, 2016</span>Nullam quis ex iaculis, blandit tellus in, tincidunt justo. Ut ex arcu.</h3>
                            </div>-->
                        </div>

                        <a class="left carousel-control" href="#notice" role="button" data-slide="prev">

                            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>

                            <span class="sr-only">Previous</span>

                        </a>

                    </div><!-- /.carousel -->

                </div>

            </div>

            <a href="#" class="add-notice"><img src="<?php echo e(asset('public/assets/img/add.png')); ?>"></a>

        </div>

        <!-- notice board -->

        <div class="pencil-bg">

            <div class="container marketing">

                <!-- START THE FEATURETTES -->





                <div class="row featurette welcome">

                    <div class="col-md-6">

                        <img class="featurette-image img-responsive center-block" alt="" src="<?php echo e(asset('public/assets/img/merry.jpg')); ?>">

                    </div>

                    <div class="col-md-6">

                        <h2><i>Welcome</i> Public Central School</h2>

                        <p class="lead">'Public Central School' Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam aliquam sed est sit amet scelerisque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Duis efficitur tempus luctus. Nulla eu dui pretium, consequat sapien vitae, vehicula lorem. Vivamus malesuada a felis non pretium. Cras a mauris in magna auctor pellentesque.Ut commodo sem eget velit feugiat mollis.Proin congue erat a dolor bibendum accumsan.</p>

                        <a href="<?php echo e(url('about')); ?>" class="btn btn-primary pull-right">Read More..</a>

                    </div>

                </div>

                <div class="row">

                    <div class="col-md-6">

                        <div class="principle-msg">

                            <div class="side">

                                <img src="<?php echo e(asset('public/assets/img/principle.jpg')); ?>" alt="" title="">

                            </div>

                            <div class="side">

                                <h3>PRINCIPAL MESSAGE</h3>

                                <p>As a principal I owe certain obligatory responsibility to students, parents teachers and the school as a whole with my varied experiences I wish to express my views on education.</p>
                                <p>In my opinion Education is a sincere and disciplined endeavor to link the mind with the self. That is why the motto of the school is &ldquo;Sa Vidya...</p>

                                <a href="<?php echo e(url('principal-desk')); ?>" class="btn btn-default pull-right">Read More..</a>

                            </div>

                        </div>

                    </div>

                    <div class="col-md-6">
                        <div class="birthday">
                            <div class="text-center">
                                <img src="<?php echo e(asset('public/assets/img/happy-birthday.png')); ?>" alt="">
                            </div>
                            <div class="clearfix"></div>
                            <div class="slide-area">
                                <!-- Carousel
                                ================================================== -->
							<div id="birthday" class="carousel slide" data-ride="carousel">
								<!-- Wrapper for slides -->
								<div class="carousel-inner" role="listbox">
								<?php if($Birthday){ foreach($Birthday as $k=>$val){ ?>
								  <div class="item <?php if($k==0){echo 'active';} ?>">
								  <?php if(!empty($val['images'])){ ?>
									<img src="<?php echo e(img_src_path()); ?>birthday/photo/<?php echo e($val['images']); ?>" alt="<?=$val['title']?>">
								  <?php }else{ ?>
									<img src="<?php echo e(asset('public/assets/img/birthday-girl-no.png')); ?>" alt="">
								  <?php } ?>
									<div class="detail">
									  <h4><?=$val['title']?><span>BIRTHDAY : <?=date('D M j',strtotime($val['dateofbirth']))?></span><span>CLASS : <?=$val['classes']?></span></h4>
									</div>
								  </div>
								<?php } } ?>
								  <!--<div class="item">
									<img src="<?php echo e(asset('public/assets/img/birthday-girl.jpg')); ?>" alt="">
									<div class="detail">
									   <h4>GEETA BISWAS<span>BIRTHDAY : 15th, Jan</span><span>CLASS : 6th A</span></h4>
									</div>
								  </div>
								  <div class="item">
									<img src="<?php echo e(asset('public/assets/img/birthday-girl.jpg')); ?>" alt="">
									<div class="detail">
									   <h4>GEETA BISWAS<span>BIRTHDAY : 15th, Jan</span><span>CLASS : 6th A</span></h4>
									</div>
								  </div>-->
								</div>
								<a class="left carousel-control" href="#birthday" role="button" data-slide="prev">
								  <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
								  <span class="sr-only">Previous</span>
								</a>
								<a class="right carousel-control" href="#birthday" role="button" data-slide="next">
								  <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
								  <span class="sr-only">next</span>
								</a>
							  </div>
                                <!-- /.carousel -->
                            </div>
                            <!-- <a href="birthday.html" class="btn btn-default pull-right"><i>View All</i></a> -->
                        </div>
                    </div>

                    <div class="clearfix"></div>

                    <div class="col-md-6">

                        <div class="gallery">

                            <div class="header-p">

                                <h4>LATEST</h4>

                                <h3>PHOTO GALLERY</h3>

                                <a href="<?php echo e(url('photo-gallery')); ?>">View All</a>

                            </div>

                            <ul class="img-sec" id="lightgallery">
							<?php if($Uploadgallery){ foreach($Uploadgallery as $gallery){ ?>
                                <li data-responsive="<?php echo e(img_src_path()); ?>uploadgallery/<?php echo e($gallery['images']); ?> 375, <?php echo e(img_src_path()); ?>uploadgallery/<?php echo e($gallery['images']); ?> 480, <?php echo e(img_src_path()); ?>uploadgallery/<?php echo e($gallery['images']); ?> 800" data-src="<?php echo e(img_src_path()); ?>uploadgallery/<?php echo e($gallery['images']); ?>" data-sub-html=''><a href=""><img src="<?php echo e(img_src_path()); ?>uploadgallery/<?php echo e($gallery['images']); ?>" alt=""></a></li>
							<?php } } ?>
                                <!--<li data-responsive="img/1-375.jpg 375, img/1-480.jpg 480, img/1.jpg 800" data-src="<?php echo e(asset('public/assets/img/ga2-b.jpg')); ?>" data-sub-html=''><a href=""><img src="<?php echo e(asset('public/assets/img/ga2.jpg')); ?>" alt=""></a></li>

                                <li data-responsive="img/1-375.jpg 375, img/1-480.jpg 480, img/1.jpg 800" data-src="<?php echo e(asset('public/assets/img/ga3-b.jpg')); ?>" data-sub-html=''><a href=""><img src="<?php echo e(asset('public/assets/img/ga3.jpg')); ?>" alt=""></a></li>

                                <li data-responsive="img/1-375.jpg 375, img/1-480.jpg 480, img/1.jpg 800" data-src="<?php echo e(asset('public/assets/img/ga4-b.jpg')); ?>" data-sub-html=''><a href=""><img src="<?php echo e(asset('public/assets/img/ga4.jpg')); ?>" alt=""></a></li>

                                <li data-responsive="img/1-375.jpg 375, img/1-480.jpg 480, img/1.jpg 800" data-src="<?php echo e(asset('public/assets/img/ga5-b.jpg')); ?>" data-sub-html=''><a href=""><img src="<?php echo e(asset('public/assets/img/ga5.jpg')); ?>" alt=""></a></li>

                                <li data-responsive="img/1-375.jpg 375, img/1-480.jpg 480, img/1.jpg 800" data-src="<?php echo e(asset('public/assets/img/ga6-b.jpg')); ?>" data-sub-html=''><a href=""><img src="<?php echo e(asset('public/assets/img/ga6.jpg')); ?>" alt=""></a></li>-->

                            </ul>

                        </div>

                    </div>

                    <div class="col-md-6">

                        <div class="portal-all">

                            <a href="#" class="port">

                                <img src="<?php echo e(asset('public/assets/img/globe.png')); ?>" alt=""><br>

                                PORTAL

                            </a>

                            <a href="#" class="kg">

                                <img src="<?php echo e(asset('public/assets/img/kg.png')); ?>" alt=""><br>

                                KG

                            </a>

                            <a href="#" class="alu">

                                <img src="<?php echo e(asset('public/assets/img/alumini.png')); ?>" alt=""><br>

                                ALUMINI

                            </a>

                        </div>

                    </div>

                </div>

            </div>



            <!-- FOOTER -->

            <footer>
                <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->yieldSection(); ?>
            </footer>



        </div><!-- /.container -->
        
        <?php echo $__env->make('includes.js_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldSection(); ?>

    </body>

</html>