<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo e(asset('public/assets/js/jquery.js')); ?>"></script>
<script> var site_url = '<?php echo e(url("/")); ?>'; </script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo e(asset('public/assets/js/bootstrap.min.js')); ?>"></script>

<script src="<?php echo e(asset('public/assets/js/jquery-ui.js')); ?>"></script>
<!-- jquery ScrollUp JS -->
<script src="<?php echo e(asset('public/assets/js/scrollup/jquery.scrollUp.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular-route.js"></script>  
<!-- Notifications JS -->

<script src="<?php echo e(asset('public/assets/js/alertify/alertify.js')); ?>"></script>

<script src="<?php echo e(asset('public/assets/js/alertify/alertify-custom.js')); ?>"></script>

<!-- BS Validator JS -->
<script src="<?php echo e(asset('public/assets/js/bsvalidator/bootstrapValidator.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/bsvalidator/custom-validations.js')); ?>"></script>

<script src="<?php echo e(asset('public/assets/tipped/tipped.js')); ?>"></script>

<!-- Data Tables -->
<script src="<?php echo e(asset('public/assets/js/datatables/dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/datatables/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/datatables/custom-datatables.js')); ?>"></script>
<!-- Custom JS -->
<script src="<?php echo e(asset('public/assets/js/custom.js')); ?>"></script>

<script>
$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){alert('dd');
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
  
  $("#CountryName").autocomplete({
	   source: '<?=url('suggestcountry')?>',
	   minLength: 2,
	   select: function (event, ui) {
		   var CountryId = ui.item.id;
		   $("#ContId").val(CountryId);
	   }
	});
	
	$("#SateName").autocomplete({
	   source: '<?=url('suggeststate')?>',
	   minLength: 2,
	   select: function (event, ui) {
		   var CountryId = ui.item.id;
		   $("#stateId").val(CountryId);
	   }
	});
	
	$("#fromcity").autocomplete({
	   source: '<?=url('suggestcity')?>',
	   minLength: 2,
	   select: function (event, ui) {
		   var CountryId = ui.item.id;
		   $("#fromcity_id").val(CountryId);
	   },
	   open: function(){
			setTimeout(function () {
				$('.ui-autocomplete').css('z-index', 99999999999999);
			}, 0);
		}
	});
	$("#tocity").autocomplete({
	   source: '<?=url('suggestcity')?>',
	   minLength: 2,
	   select: function (event, ui) {
		   var CountryId = ui.item.id;
		   $("#tocity_id").val(CountryId);
	   },
	   open: function(){
			setTimeout(function () {
				$('.ui-autocomplete').css('z-index', 99999999999999);
			}, 0);
		}
	});
	
	$('.checkbalance').on("click", function(e){
		$.ajax({
			url:'<?=url('currentbalance')?>',
			type: 'GET',
			dataType: 'json',
			beforeSend: function(){ $('#current_bal').html('<center>Loading...</center>')},
			success:function(result){
				$('#current_bal').html('Current Balance: INR '+result.current_balance);
			},
			error:function(result){
				alertify.error('Execution error !!');
			}
		
		});
		
	});
	
});
</script>