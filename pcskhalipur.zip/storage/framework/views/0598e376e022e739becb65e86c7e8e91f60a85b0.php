<link rel="shortcut icon" href="<?php echo e(asset('public/assets/img/favicon.ico')); ?>">
<!-- Bootstrap CSS -->
<link href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>" media="screen" rel="stylesheet" />

<!-- Main CSS -->
<link href="<?php echo e(asset('public/assets/css/main.css')); ?>" rel="stylesheet" media="screen" />

<!-- Ion Icons -->
<link href="<?php echo e(asset('public/assets/fonts/icomoon/icomoon.css')); ?>" rel="stylesheet" />

<!-- Alertify CSS -->
<link href="<?php echo e(asset('public/assets/css/alertify/core.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/assets/css/alertify/default.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('public/assets/fonts/font-awesome.css')); ?>" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/jquery-ui.css')); ?>">
<!-- C3 CSS -->
<link href="<?php echo e(asset('public/assets/css/c3/c3.css')); ?>" rel="stylesheet" />

<link href="<?php echo e(asset('public/assets/tipped/tipped.css')); ?>" rel="stylesheet" />

<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/datatables/dataTables.bs.min.css')); ?>">
<!-- Circliful CSS -->
<link href="<?php echo e(asset('public/assets/css/circliful/circliful.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('public/assets/css/loading.css')); ?>" rel="stylesheet"  />

<style>

.dropdown-submenu {
    position: relative;
}

.dropdown-submenu>.dropdown-menu {
    top: 0;
    left: 100%;
    margin-top: -6px;
    margin-left: -1px;
    -webkit-border-radius: 0 6px 6px 6px;
    -moz-border-radius: 0 6px 6px;
    border-radius: 0 6px 6px 6px;
}

.dropdown-submenu:hover>.dropdown-menu {
    display: block;
}

.dropdown-submenu>a:after {
    display: block;
    content: " ";
    float: right;
    width: 0;
    height: 0;
    border-color: transparent;
    border-style: solid;
    border-width: 5px 0 5px 5px;
    border-left-color: #ccc;
    margin-top: 5px;
    margin-right: -10px;
}

.dropdown-submenu:hover>a:after {
    border-left-color: #fff;
}

.dropdown-submenu.pull-left {
    float: none;
}

.dropdown-submenu.pull-left>.dropdown-menu {
    left: -100%;
    margin-left: 10px;
    -webkit-border-radius: 6px 0 6px 6px;
    -moz-border-radius: 6px 0 6px 6px;
    border-radius: 6px 0 6px 6px;
}
</style>
