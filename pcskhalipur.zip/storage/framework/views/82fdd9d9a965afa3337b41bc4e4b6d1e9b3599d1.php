<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
                
        <?php echo $__env->make('includes.css_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldSection(); ?>

    </head>

    <!-- NAVBAR
    
    ================================================== -->

    <body>

        <div class="navbar-wrapper">
			<?php echo $__env->make('includes.menu_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldSection(); ?>  
        </div>    

        <!-- Carousel
    
        ================================================== -->

<div class="banner">

  <img src="<?php echo e(asset('public/assets/img/about_banner.jpg')); ?>" alt="..." class="img-responsive">

</div>

<div class="pencil-bg">

  <div class="container inr-page">

    <div class="col-sm-9 con-area">

      <h1 class="heading">

        Photo Gallery<br>

        <img src="<?php echo e(asset('public/assets/img/hed-sep.jpg')); ?>" alt="">

      </h1>
	  
	  <div class="gallery1">
            <ul class="img-sec" id="lightgallery">
			<?php 
			if($Uploadgallery){
				foreach($Uploadgallery as $val){
					
			?>
              <li data-responsive="<?php echo e(img_src_path()); ?>uploadgallery/<?php echo e($val->images); ?> 375, <?php echo e(img_src_path()); ?>uploadgallery/<?php echo e($val->images); ?> 480, <?php echo e(img_src_path()); ?>uploadgallery/<?php echo e($val->images); ?> 800" data-src="<?php echo e(img_src_path()); ?>uploadgallery/<?php echo e($val->images); ?>" data-sub-html=''><a href=""><img src="<?php echo e(img_src_path()); ?>uploadgallery/<?php echo e($val->images); ?>" alt=""></a></li>
			  <?php 
				}
			}
			  ?>
              
            </ul>
          </div>
		  
      <p>&nbsp;</p>

    
    </div>

    <div class="col-sm-3">
	
	<ul class="side-list">
		<li><a href="<?php echo e(url('photo-gallery')); ?>" class="active">Photo Gallery </a></li>
		<li><a href="#">Vedo Gallery </a></li>
    </ul>

      <div class="col-md-12" style="padding:0;">
			<?php echo $__env->make('includes.latest_news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldSection(); ?>
		</div>

  <div class="clearfix">&nbsp;</div>
  </div>
   <div class="clearfix">&nbsp;</div>
</div>

  </div>


            <!-- FOOTER -->

            <footer>
                <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->yieldSection(); ?>
            </footer>



        </div><!-- /.container -->
        
        <?php echo $__env->make('includes.js_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldSection(); ?>

    </body>

</html>