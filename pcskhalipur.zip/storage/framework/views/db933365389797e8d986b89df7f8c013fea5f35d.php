<?php 
//print_r($bustype);die;
?>
<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Tekoffice | B2B and B2C market place" />
<meta name="keywords" content="B2B and B2C market place, manage hotels, holidays package and flight" />
<meta name="author" content="Tekoffice" />
<title>Dashboard</title>
<?php echo $__env->make('includes.css_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	<?php echo $__env->yieldSection(); ?>
</head>

<body>

<!-- Header starts --> 
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	<?php echo $__env->yieldSection(); ?> 
<!-- Header ends --> 

<!-- Container fluid Starts -->
<div class="container-fluid"> 
  
  <!-- Navbar starts --> 
  <?php echo $__env->make('includes.menu_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldSection(); ?> 
  <!-- Navbar ends --> 
  
  <!-- Dashboard wrapper starts -->
  <div class="dashboard-wrapper"> 
    
    <!-- Top bar starts -->
    <div class="top-bar clearfix">
      <div class="row gutter">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <div class="page-title">
            <h4>Add/Update Coach</h4>
          </div>
        </div>
        
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <ul class="right-stats" id="mini-nav-right">
                <li>
                    <a href="<?php echo e(url('managecoach')); ?>" class="btn btn-danger">Manage Coach</a>
                </li>
                <li>
                    <a href="<?php echo e(url('newcoach')); ?>" class="btn btn-success">Create Coach</a>
                </li>
            </ul>
        </div>
      </div>
    </div>
    <!-- Top bar ends --> 
    
    <!-- Main container starts -->
    <div class="main-container">
    <?php if(session('msgerror')): ?>
    <div class="alert alert-danger light no-margin">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <i class="icon-cross2"></i> <?php echo e(session('msgerror')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('msgsuccess')): ?>
    <div class="alert alert-success light no-margin">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <i class="icon-check_circle"></i> <?php echo e(session('msgsuccess')); ?>

    </div>
    <?php endif; ?>
      <ul class="nav nav-tabs tabs-up" id="friends">
      <?php if(!$id): ?>
        <li class="active"><a href="<?php echo e(url('newcoach')); ?>" id="coachinfo"> Coach Info </a></li>
        <?php else: ?>
        <li class="active"><a href="<?php echo e(url('newcoach/'.$id)); ?>" id="coachinfo"> Coach Info </a></li>
        <li><a href="<?php echo e(url('seatlayout/'.$id)); ?>"> Seat Layout</a></li>
        <li><a href="<?php echo e(url('coachgallery/'.$id)); ?>"  data-toggle="tabajax">Coach Gallery</a></li>
        <?php endif; ?>
      </ul>
      <div class="tab-content">
        <div class="tab-pane active" id="contacts">
        	<?php echo Form::model($array, array('action' => array('FrontController@newcoach',$id), 'files'=>true, 'method' => 'POST', 'id' => 'newcoach')); ?>

            <div class="form-group">
              <div class="row gutter">
                <div class="col-md-4">
                  <label class="control-label">Coach Name</label>
                  <?php echo Form::text('name',null,['class' => 'form-control','placeholder' => 'Coach Name']); ?>

                </div>
                <div class="col-md-4">	
                  <label class="control-label">Bus Type</label>
                 <?php echo Form::select('bus_type', $bustype, null, ['class'=>'form-control ','placeholder' => '--Select--']); ?>

                </div>
                <div class="col-md-4">
                  <label class="control-label">Vehicle Company</label>
                  <?php echo Form::select('vehicle', $vehicleMaker, null, ['class'=>'form-control ','placeholder' => '--Select--']); ?>

                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="row gutter">
                <div class="col-md-4">
                  <label class="control-label">Layout type</label>
                  <?php echo Form::select('layout_type', $layout_type, null, ['class'=>'form-control ','placeholder' => '--Select--']); ?>

                </div>
                <div class="col-md-4">
                  <label class="control-label">Is ac</label>
                  <select class="form-control" name="isac">
                    <option value="">--Select--</option>
                    <option value="AC" <?=(!empty($array->isac) && $array->isac == 'AC')?'selected':''?>>AC</option>
                    <option value="Non-AC" <?=(!empty($array->isac) && $array->isac == 'Non-AC')?'selected':''?>>Non-AC</option>
                  </select>
                </div>
                <div class="col-md-4">
                  <label class="control-label">Coach Feature</label>
                  <?php echo Form::select('coachfeature', $coachfeature, null, ['class'=>'form-control ','placeholder' => '--Select--']); ?>

                </div>
              </div>
            </div>
            <div class="form-group no-margin">
              <div class="row gutter">
                <div class="col-lg-offset-6 pull-right">
                  <button type="submit" class="btn btn-success">Save & Next</button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
      
      
    </div>
    <!-- Main container ends --> 
    
  </div>
  <!-- Dashboard Wrapper End --> 
  
</div>
<!-- Container fluid ends --> 

<?php echo $__env->make('includes.copy_right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	<?php echo $__env->yieldSection(); ?>

		<?php echo $__env->make('includes.js_common_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	<?php echo $__env->yieldSection(); ?> 
<script>
		$(document).ready(function(){
			$('.newcoach').click(function(){
				var page = $(this).attr("pg");
				
			});
			
			
		});
		</script>
</body>
</html>