<nav class="navbar navbar-default">
				<div class="navbar-header">
					<span class="navbar-text">Menu</span>
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse-navbar" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="collapse-navbar">
					<ul class="nav navbar-nav">
						<li class="active">
							<a href="<?php echo e(url('/')); ?>"><i class="icon-blur_on"></i>Dashboard</a>
						</li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="icon-reorder"></i> Admin Master <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                              <!--<li><a tabindex="-1" href="#">Geo Category</a></li>
                              <li><a tabindex="-1" href="#">CSS</a></li>-->
                              <li class="dropdown-submenu">
                                <a class="test" tabindex="-1" href="#">Geo Category </a>
                                <ul class="dropdown-menu">
                                  <li><a tabindex="-1" href="#">Country</a></li>
                                  <li><a tabindex="-1" href="<?php echo e(url('addstate')); ?>">State</a></li>
                                  <li><a tabindex="-1" href="<?php echo e(url('addcity')); ?>">City</a></li>
                                  <!--<li class="dropdown-submenu">
                                    <a class="test" href="#">Another dropdown </a>
                                    <ul class="dropdown-menu">
                                      <li><a href="#">3rd level dropdown</a></li>
                                      <li><a href="#">3rd level dropdown</a></li>
                                    </ul>
                                  </li>-->
                                </ul>
                              </li>
                              
                              <li class="dropdown-submenu">
                                <a class="test" tabindex="-1" href="#">Master Entity </a>
                                <ul class="dropdown-menu">
                                	<!--<li class="dropdown-submenu">
                                    <a class="test" href="#">Bus Master</a>
                                    <ul class="dropdown-menu">
                                      <li><a href="#">Bus Pickup/Drop</a></li>
                                      <li><a href="#">But Type</a></li>
                                    </ul>
                                  </li>-->
                                  <li><a tabindex="-1" href="<?php echo e(url('masterentity')); ?>">Master</a></li>
                                  <li><a tabindex="-1" href="<?php echo e(url('busstation')); ?>">Add Bus Station</a></li>
                                  <li><a tabindex="-1" href="#">Pin Code/Location</a></li>
                                </ul>
                              </li>
                              
                            </ul>
                          </li>
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-bus"></i> Bus <span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li>
									<a href="<?php echo e(url('managecoach')); ?>">Manage Coach</a>
								</li>
								<li>
									<a href="<?php echo e(url('manageroute')); ?>">Manage Routes</a>
								</li>
								<li>
									<a href="<?php echo e(url('bus-searchbus')); ?>">Bus Booking</a>
								</li>
								<!--<li>
									<a href='tasks.html'>Promotion</a>
								</li>
								<li>
									<a href='tasks.html'>Not Valid</a>
								</li>-->
								
							</ul>
						</li>
						
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-users"></i> User Panel <span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li>
									<a href='profile.html'>Create User</a>
								</li>
								<li>
									<a href='tasks.html'>Manage User</a>
								</li>
								
							</ul>
						</li>
                        
                        <li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="icon-view_week"></i> Booking Ques <span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li>
									<a href="<?php echo e(url('busbooking')); ?>">Bus</a>
								</li>
								<li>
									<a href='#'>Accommodation</a>
								</li>
							</ul>
						</li>
                        
                        <li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-area-chart"></i> Report <span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li>
									<a href='profile.html'>Sales Report</a>
								</li>
								<li>
									<a href='tasks.html'>Account</a>
								</li>
							</ul>
						</li>
                        
                        <li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-internet-explorer"></i> E-Marketing <span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li>
									<a href='#'>Agency Mail Bank</a>
								</li>
								<li>
									<a href='#'>News Letter</a>
								</li>
                                <li>
									<a href='#'>Registerd Agent</a>
								</li>
                                <li>
									<a href='#'>Registerd Supplier</a>
								</li>
                                <li>
									<a href='#'>Mailer</a>
								</li>
                                
							</ul>
						</li>
                        
						<li>
							<a href="#"><i class="fa fa-database"></i>Data Bank</a>
						</li>
						
						
					</ul>
				</div>
			</nav>