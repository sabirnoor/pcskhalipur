<?php 
//print_r($bustype);die;
?>
<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Tekoffice | B2B and B2C market place" />
<meta name="keywords" content="B2B and B2C market place, manage hotels, holidays package and flight" />
<meta name="author" content="Tekoffice" />
<title>Dashboard</title>
<?php echo $__env->make('includes.css_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldSection(); ?>

</head>

<body>

<!-- Header starts --> 
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	<?php echo $__env->yieldSection(); ?> 
<!-- Header ends --> 

<!-- Container fluid Starts -->
<div class="container-fluid"> 
  
  <!-- Navbar starts --> 
  <?php echo $__env->make('includes.menu_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldSection(); ?> 
  <!-- Navbar ends --> 
  
  <!-- Dashboard wrapper starts -->
  <div class="dashboard-wrapper"> 
    
    <!-- Top bar starts -->
    <div class="top-bar clearfix">
      <div class="row gutter">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <div class="page-title">
            <h4>Bus Transaction</h4>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <ul class="right-stats" id="mini-nav-right">
            <li> <a href="<?php echo e(url('busbooking')); ?>" class="btn btn-success">Manage</a> </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- Top bar ends --> 
    
    <!-- Main container starts -->
    <div class="main-container">
      <div class="row gutter">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="panel-body">
              <div class="table-responsive">
                <table id="" class="table table-bordered" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>PNR No.</th>
                      <th>Customer</th>
                      <th>Bus Type</th>
                      <th>Total Pax</th>
                      <th>Seat No.</th>
                      <th>From</th>
                      <th>To</th>
                      <th>Travel Date</th>
                      <th>Amount</th>
                      <th>TXN Date</th>
                      <th>Mode</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  
                  <tbody>
                  <?php if($bookingList): ?>
						<?php $__currentLoopData = $bookingList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($val->id); ?>">
                      <td> <?php echo ($bookingList->perPage()*($bookingList->currentPage()-1))+($k+1);?></td>
                      <td><?php echo e($val->pnr_numbers); ?></td>
                      <td><?php echo e($val->pax_name); ?> <br> <?php echo e($val->emailid); ?><br> <?php echo e($val->mobileno); ?></td>
                      <td><?php echo e($val->coachName); ?></td>
                      <td><?php echo e($val->TotalPax); ?></td>
                      <td><?php echo e($val->seatnumber); ?></td>
					  <td><?php echo e($val->fromcity_name); ?></td>
                      <td><?php echo e($val->tocity_name); ?></td>
                      <td><?php echo e(date('d-M-Y',strtotime($val->traveldate))); ?></td>
					  <td><?php echo e($val->paynetfare); ?></td>
					  <td><?php echo e($val->created_on); ?></td>
					  <td>Online</td>
					  <td>Success</td>
                      <td>
					  <div class="btn-group" id="flight_9604">
							<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
								Select <span class="caret"></span>
							</button>
							<ul class="dropdown-menu pull-right" role="menu">
								<li><a target="_blank" href="<?php echo e(url('PrintTicket', ['id' => $val->id])); ?>" title="">Print Ticket</a></li>
								<li><a href="#" title="">Resend Mail</a></li>
								<li><a href="javascript:void(0);" data-toggle="modal" data-target="#TicketDetails" title="View Details" onclick="TicketDetails('<?php echo e($val->id); ?>');">Details</a></li>
								<li><a href="#" title="">Discard</a></li>
							</ul>
						</div>
					 
                      </td>
                    </tr>
                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>	
                    
                  </tbody>
                </table>
				<?php echo e($bookingList ->links()); ?>

              </div>
            </div>
        </div>
      </div>
    </div>
    <!-- Main container ends --> 
    
  </div>
  <!-- Dashboard Wrapper End --> 
  
</div>
<!-- Container fluid ends --> 
<div class="modal fade" id="TicketDetails" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"></div>
<?php echo $__env->make('includes.copy_right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('includes.js_common_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldSection(); ?> 
<script>

function TicketDetails(id) {
    $.ajax({
        url: 'TicketDetailsPop/'+id,
        type: 'POST',
        dataType: 'html',
        error: function () {
        },
        beforeSend: function () {
            var image = "<div class= 'mydivcenter' ><div class='loading-k'></div></div>";
            $("#TicketDetails").html(image);
        },
        success: function (response) {
            $("#TicketDetails").show();
            $("#TicketDetails").html(response);

            //alert(response);
        }
    });
}
function closepopup() {
    $("#TicketDetails").hide();
}
$(document).ready(function(){
	$('.newcoach').click(function(){
		var page = $(this).attr("pg");
		
	});
	
	
});
</script>
</body>
</html>