<?php 
//print_r($entity_type);die;
?>
<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="Tekoffice | B2B and B2C market place" />
<meta name="keywords" content="B2B and B2C market place, manage hotels, holidays package and flight" />
<meta name="author" content="Tekoffice" />
<title>Dashboard</title>
<?php echo $__env->make('includes.css_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldSection(); ?>
<style>
.seat_box {
    height: 38px;
    text-align: center;
    width: 38px;
    border: 0px solid #CCC;
}
.create_table {
	overflow: hidden;
	width:100%;
}
.create_table table {
	border-top: solid 1px #ccc;
	border-left: solid 1px #ccc;
}
.create_table table td {
	padding:0px 0px;
	vertical-align: middle;
	border-bottom: solid 1px #ccc;
	border-right: solid 1px #ccc;
	font-size:12px;
}
</style>
</head>

<body>

<!-- Header starts --> 
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldSection(); ?> 
<!-- Header ends --> 

<!-- Container fluid Starts -->
<div class="container-fluid"> 
  
  <!-- Navbar starts --> 
  <?php echo $__env->make('includes.menu_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldSection(); ?> 
  <!-- Navbar ends --> 
  
  <!-- Dashboard wrapper starts -->
  <div class="dashboard-wrapper"> 
    
    <!-- Top bar starts -->
    <div class="top-bar clearfix">
      <div class="row gutter">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <div class="page-title">
            <h4>Coach Gallery - <?php echo e(CoachName($id)); ?></h4>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <ul class="right-stats" id="mini-nav-right">
                <li>
                    <a href="<?php echo e(url('managecoach')); ?>" class="btn btn-danger">Manage Coach</a>
                </li>
                <li>
                    <a href="<?php echo e(url('newcoach')); ?>" class="btn btn-success">Create Coach</a>
                </li>
            </ul>
        </div>
      </div>
    </div>
    <!-- Top bar ends --> 
    
    <!-- Main container starts -->
    <div class="main-container">
      <ul class="nav nav-tabs" id="friends">
        <li><a href="<?php echo e(url('newcoach/'.$id)); ?>" id="coachinfo"> Coach Info </a></li>
        <li><a href="<?php echo e(url('seatlayout/'.$id)); ?>"> Seat Layout</a></li>
        <li class="active"><a href="<?php echo e(url('coachgallery/'.$id)); ?>"  >Coach Gallery</a></li>
      </ul>
     <div class="tab-content">
        <div class="tab-pane active" id="contacts">
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
		<?php if(session('msgerror')): ?>
		<div class="alert alert-danger light no-margin">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<i class="icon-cross2"></i> <?php echo e(session('msgerror')); ?>

		</div>
		<?php endif; ?>
		<?php if(session('msgsuccess')): ?>
		<div class="alert alert-success light no-margin">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<i class="icon-check_circle"></i> <?php echo e(session('msgsuccess')); ?>

		</div>
		<?php endif; ?>
			<div class="panel">
				<div class="panel-heading">
					<h4>Coach Gallery </h4>
				</div>
				<?php echo Form::model($array, array('action' => array('FrontController@coachgallery',$id,$gallery_id), 'files'=>true, 'method' => 'POST', 'id' => 'coachgallery')); ?>

				<div class="panel-body">
					<div class="form-group">
						<label for="userName">Image Title</label>
						<?php echo Form::text('name',null,['class' => 'form-control','placeholder' => 'Image Title']); ?>

					</div>
					<div class="form-group">
						<label for="image">Image</label>
						<input type="file" class="form-control" name="image" id="image">
					</div>
					<div class="form-group no-margin">
					  <div class="row gutter">
						<div class="col-lg-offset-6 pull-right">
						  <button type="submit" class="btn btn-success">Save</button>
						</div>
					  </div>
					</div>
				</div>
				</form>
			</div>
		</div>
		<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
			<div class="panel">
				<div class="panel-heading">
					<h4>Gallery List</h4>
				</div>
				<div class="panel-body">
					<div class="table-responsive">
						<table id="responsiveTable" class="table table-striped table-bordered no-margin" cellspacing="0" width="100%">
							<thead>
							  <tr>
							  <th>Coach</th>
							  <th>Image Title</th>
							  <th>Entity</th>
							  <th>Action</th>
							  </tr>
							</thead>
							<tfoot>
							  <tr>
							  <th>Coach</th>
							  <th>Image Title</th>
							  <th>Image</th>
							  <th>Action</th>
							  </tr>
							</tfoot>
							<tbody>
							
							<?php if($CoachGalleryList): ?>
								<?php $__currentLoopData = $CoachGalleryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <tr id="<?php echo e($val->id); ?>">
								<td><?php echo e($val->name); ?></td>
								<td><?php echo e($val->name); ?></td>
								<td><img src="<?php echo src_path().'coachgallery/gid/'.$id.'/mob_'.$val->coachimage; ?>" height="50" class=" img-circle-sm" alt="avatar"></td>
								<td>
								<a href="<?php echo e(url('coachgallery/'.$id.'/'.$val->id)); ?>" title="Update" class="text-success"><i class="fa fa-pencil-square-o fa-1x"></i></a>
									<a href="javascript::void(0);" title="Delete" id="<?php echo e($val->id); ?>" class="text-danger deleteGallery"><i class="fa fa-trash-o fa-1x"></i></a>
								</td>	
							  </tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>	
							  
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
        	
           
            <div class="form-group no-margin">
              <div class="row gutter">
                
              </div>
            </div>
          
        </div>
      </div>
      
    </div>
    <!-- Main container ends --> 
    
  </div>
  <!-- Dashboard Wrapper End --> 
  
</div>
<!-- Container fluid ends --> 

<?php echo $__env->make('includes.copy_right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	<?php echo $__env->yieldSection(); ?>

		<?php echo $__env->make('includes.js_common_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 	<?php echo $__env->yieldSection(); ?> 
<script>
		$(document).ready(function(){
			$('.newcoach').click(function(){
				var page = $(this).attr("pg");
				
			});
			
			
		});
		</script>
</body>
</html>