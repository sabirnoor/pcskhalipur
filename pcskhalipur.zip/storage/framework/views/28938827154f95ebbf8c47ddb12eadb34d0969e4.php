<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo e(asset('public/assets/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jquery-ui.js')); ?>"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo e(asset('public/assets/js/bootstrap.min.js')); ?>"></script>

<!-- Sparkline Graphs -->
<script src="<?php echo e(asset('public/assets/js/sparkline/retina.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/sparkline/custom-sparkline.js')); ?>"></script>

<!-- jquery ScrollUp JS -->
<!-- jquery ScrollUp JS -->
<script src="<?php echo e(asset('public/assets/js/scrollup/jquery.scrollUp.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular-route.js"></script> 
<script src="<?php echo e(asset('public/assets/js/alertify/alertify.js')); ?>"></script>

<script src="<?php echo e(asset('public/assets/js/alertify/alertify-custom.js')); ?>"></script>
<!-- D3 JS -->
<script src="<?php echo e(asset('public/assets/js/d3/d3.v3.min.js')); ?>"></script>

<!-- C3 Graphs -->
<script src="<?php echo e(asset('public/assets/js/c3/c3.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/c3/c3.custom.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/tipped/tipped.js')); ?>"></script>
<!-- JVector Map -->
<script src="<?php echo e(asset('public/assets/js/jvectormap/jquery-jvectormap-2.0.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jvectormap/world-mill-en.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jvectormap/gdp-data.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jvectormap/world-map.js')); ?>"></script>

<!-- Circliful js -->
<script src="<?php echo e(asset('public/assets/js/circliful/circliful.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/circliful/circliful.custom.js')); ?>"></script>

<!-- Peity JS -->
<script src="<?php echo e(asset('public/assets/js/peity/peity.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/peity/custom-peity.js')); ?>"></script>

<!-- Custom JS -->
<script src="<?php echo e(asset('public/assets/js/custom.js')); ?>"></script>

<script>
$(document).ready(function(){
  $('.dropdown-submenu a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
  
  $('.checkbalance').on("click", function(e){
		$.ajax({
			url:'<?=url('currentbalance')?>',
			type: 'GET',
			dataType: 'json',
			beforeSend: function(){ $('#current_bal').html('<center>Loading...</center>')},
			success:function(result){
				$('#current_bal').html('Current Balance: INR '+result.current_balance);
			},
			error:function(result){
				alertify.error('Execution error !!');
			}
		
		});
		
	});
	
});
</script>