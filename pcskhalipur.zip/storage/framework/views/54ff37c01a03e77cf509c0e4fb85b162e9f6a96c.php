<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
                
        <?php echo $__env->make('includes.css_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldSection(); ?>

    </head>

    <!-- NAVBAR
    
    ================================================== -->

    <body>

        <div class="navbar-wrapper">
			<?php echo $__env->make('includes.menu_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldSection(); ?>  
        </div>    

        <!-- Carousel
    
        ================================================== -->

        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

            <!-- Indicators -->

            <ol class="carousel-indicators">

                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>

                <li data-target="#carousel-example-generic" data-slide-to="1"></li>

            </ol>



            <!-- Wrapper for slides -->

            <div class="carousel-inner" role="listbox">

                <div class="item active">

                    <img src="<?php echo e(asset('public/assets/img/banner.jpg')); ?>" alt="...">

                </div>

                <div class="item">

                    <img src="<?php echo e(asset('public/assets/img/banner1.jpg')); ?>" alt="...">

                </div>

            </div>



            <!-- Controls -->

            <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">

                <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>

                <span class="sr-only">Previous</span>

            </a>

            <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">

                <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>

                <span class="sr-only">Next</span>

            </a>

        </div><!-- /.carousel -->





        <!-- notice board -->

        <div class="notice-board">

            <div class="container">

                <h1 class="heading">NOTICE 

                    BOARD</h1>

                <div class="slide-area">

                    <!-- Carousel
              
                    ================================================== -->

                    <div id="notice" class="carousel slide" data-ride="carousel">

                         <!-- Wrapper for slides -->

                         <div class="carousel-inner" role="listbox">

                            <div class="item active">

                                <h3><span>Updated on: 2th Apr, 2016</span>Nullam quis ex iaculis, blandit tellus in, tincidunt justo. Ut ex arcu.</h3>

                            </div>

                            <div class="item">

                                <h3><span>Updated on: 2th Apr, 2016</span>Nullam quis ex iaculis, blandit tellus in, tincidunt justo. Ut ex arcu.</h3>

                            </div>

                            <div class="item">

                                <h3><span>Updated on: 2th Apr, 2016</span>Nullam quis ex iaculis, blandit tellus in, tincidunt justo. Ut ex arcu.</h3>

                            </div>

                            <div class="item">

                                <h3><span>Updated on: 2th Apr, 2016</span>Nullam quis ex iaculis, blandit tellus in, tincidunt justo. Ut ex arcu.</h3>

                            </div>

                        </div>

                        <a class="left carousel-control" href="#notice" role="button" data-slide="prev">

                            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>

                            <span class="sr-only">Previous</span>

                        </a>

                    </div><!-- /.carousel -->

                </div>

            </div>

            <a href="notice_board.html" class="add-notice"><img src="<?php echo e(asset('public/assets/img/add.png')); ?>"></a>

        </div>

        <!-- notice board -->

        <div class="pencil-bg">

            <div class="container marketing">

                <!-- START THE FEATURETTES -->





                <div class="row featurette welcome">

                    <div class="col-md-6">

                        <img class="featurette-image img-responsive center-block" alt="" src="<?php echo e(asset('public/assets/img/merry.jpg')); ?>">

                    </div>

                    <div class="col-md-6">

                        <h2><i>Welcome</i> Public Central School</h2>

                        <p class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam aliquam sed est sit amet scelerisque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Duis efficitur tempus luctus. Nulla eu dui pretium, consequat sapien vitae, vehicula lorem. Vivamus malesuada a felis non pretium. Cras a mauris in magna auctor pellentesque.Ut commodo

                            sem eget velit feugiat mollis.Proin congue erat a dolor bibendum accumsan.</p>

                        <a href="#" class="btn btn-primary pull-right">Read More..</a>

                    </div>

                </div>

                <div class="row">

                    <div class="col-md-6">

                        <div class="principle-msg">

                            <div class="side">

                                <img src="<?php echo e(asset('public/assets/img/principle.jpg')); ?>" alt="" title="">

                            </div>

                            <div class="side">

                                <h3>PRINCIPAL MASSAGE</h3>

                                <p>Dear All,   Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam aliquam sed est sit amet scelerisque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Duis efficitur tempus luctus. Nulla eu dui pretium, consequat 

                                    sem eget velit feugiat mollis.Proin congue erat a dolor bibendum accumsan.</p>

                                <a href="principal_message.html" class="btn btn-default pull-right">Read More..</a>

                            </div>

                        </div>

                    </div>

                    <div class="col-md-6">

                        <div class="birthday">

                            <div class="text-center">

                                <img src="<?php echo e(asset('public/assets/img/happy-birthday.png')); ?>" alt="">

                            </div>

                            <div class="clearfix"></div>

                            <div class="slide-area">

                                <!-- Carousel
                  
                                ================================================== -->

                                <div id="birthday" class="carousel slide" data-ride="carousel">

                                    <!-- Wrapper for slides -->

                                    <div class="carousel-inner" role="listbox">

                                        <div class="item active">

                                            <img src="<?php echo e(asset('public/assets/img/birthday-girl.jpg')); ?>" alt="">

                                            <div class="detail">

                                                <h4>

                                                    GEETA BISWAS

                                                    <span>BIRTHDAY : 15th, Jan</span>

                                                    <span>CLASS : 6th A</span>

                                                </h4>

                                            </div>

                                        </div>

                                        <div class="item">

                                            <img src="<?php echo e(asset('public/assets/img/birthday-girl.jpg')); ?>" alt="">

                                            <div class="detail">

                                                <h4>

                                                    GEETA BISWAS

                                                    <span>BIRTHDAY : 15th, Jan</span>

                                                    <span>CLASS : 6th A</span>

                                                </h4>

                                            </div>

                                        </div>

                                        <div class="item">

                                            <img src="<?php echo e(asset('public/assets/img/birthday-girl.jpg')); ?>" alt="">

                                            <div class="detail">

                                                <h4>

                                                    GEETA BISWAS

                                                    <span>BIRTHDAY : 15th, Jan</span>

                                                    <span>CLASS : 6th A</span>

                                                </h4>

                                            </div>

                                        </div>

                                    </div>

                                    <a class="left carousel-control" href="#birthday" role="button" data-slide="prev">

                                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>

                                        <span class="sr-only">Previous</span>

                                    </a>

                                    <a class="right carousel-control" href="#birthday" role="button" data-slide="next">

                                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>

                                        <span class="sr-only">next</span>

                                    </a>

                                </div>

                                <!-- /.carousel -->

                            </div>

                            <a href="birthday.html" class="btn btn-default pull-right"><i>View All</i></a>    

                        </div>

                    </div>

                    <div class="clearfix"></div>

                    <div class="col-md-6">

                        <div class="gallery">

                            <div class="header-p">

                                <h4>2nd, Jan, 2016</h4>

                                <h3>STUDENT CORNER</h3>

                                <a href="#">View All</a>

                            </div>

                            <ul class="img-sec" id="lightgallery">

                                <li data-responsive="img/1-375.jpg 375, img/1-480.jpg 480, img/1.jpg 800" data-src="img/ga1-b.jpg" data-sub-html=''><a href=""><img src="<?php echo e(asset('public/assets/img/ga1.jpg')); ?>" alt=""></a></li>

                                <li data-responsive="img/1-375.jpg 375, img/1-480.jpg 480, img/1.jpg 800" data-src="img/ga2-b.jpg" data-sub-html=''><a href=""><img src="<?php echo e(asset('public/assets/img/ga2.jpg')); ?>" alt=""></a></li>

                                <li data-responsive="img/1-375.jpg 375, img/1-480.jpg 480, img/1.jpg 800" data-src="img/ga3-b.jpg" data-sub-html=''><a href=""><img src="<?php echo e(asset('public/assets/img/ga3.jpg')); ?>" alt=""></a></li>

                                <li data-responsive="img/1-375.jpg 375, img/1-480.jpg 480, img/1.jpg 800" data-src="img/ga4-b.jpg" data-sub-html=''><a href=""><img src="<?php echo e(asset('public/assets/img/ga4.jpg')); ?>" alt=""></a></li>

                                <li data-responsive="img/1-375.jpg 375, img/1-480.jpg 480, img/1.jpg 800" data-src="img/ga5-b.jpg" data-sub-html=''><a href=""><img src="<?php echo e(asset('public/assets/img/ga5.jpg')); ?>" alt=""></a></li>

                                <li data-responsive="img/1-375.jpg 375, img/1-480.jpg 480, img/1.jpg 800" data-src="img/ga6-b.jpg" data-sub-html=''><a href=""><img src="<?php echo e(asset('public/assets/img/ga6.jpg')); ?>" alt=""></a></li>

                            </ul>

                        </div>

                    </div>

                    <div class="col-md-6">

                        <div class="portal-all">

                            <a href="#" class="port">

                                <img src="<?php echo e(asset('public/assets/img/globe.png')); ?>" alt=""><br>

                                PORTAL

                            </a>

                            <a href="#" class="kg">

                                <img src="<?php echo e(asset('public/assets/img/kg.png')); ?>" alt=""><br>

                                KG

                            </a>

                            <a href="#" class="alu">

                                <img src="<?php echo e(asset('public/assets/img/alumini.png')); ?>" alt=""><br>

                                ALUMINI

                            </a>

                        </div>

                    </div>

                </div>

            </div>



            <!-- FOOTER -->

            <footer>
                <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->yieldSection(); ?>
            </footer>



        </div><!-- /.container -->
        
        <?php echo $__env->make('includes.js_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldSection(); ?>

    </body>

</html>