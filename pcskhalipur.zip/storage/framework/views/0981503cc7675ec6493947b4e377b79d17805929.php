<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
                
        <?php echo $__env->make('includes.css_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldSection(); ?>

    </head>

    <!-- NAVBAR
    
    ================================================== -->

    <body>

        <div class="navbar-wrapper">
			<?php echo $__env->make('includes.menu_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->yieldSection(); ?>  
        </div>    

        <!-- Carousel
    
        ================================================== -->

<div class="banner">

  <img src="<?php echo e(asset('public/assets/img/about_banner.jpg')); ?>" alt="..." class="img-responsive">

</div>

<div class="pencil-bg">

  <div class="container inr-page">
  
	<div class="col-sm-9  con-area">
      <h1 class="heading">
        Director's Desk<br>
        <img src="<?php echo e(asset('public/assets/img/hed-sep.jpg')); ?>" alt="">
      </h1>
     <h3>Director Message</h3>
      <p>
       <img src="<?php echo e(asset('public/assets/img/dir.jpg')); ?>" class="img-right">
      <strong>Md. Mujtaba Hasan (Chairman)</strong><br>
It is a long felt demand of this locality and neighboring areas to set up a school of high standard to impart quality education. It is a demanding task at present. Therefore we intended to fulfill it with strong determination and hard work. As a result we succeeded in setting up this "Public Central School" in the Year 2007-2008 managed by Public Educational and Welfare Society, Regd. Under Society Act 21, 1860 Govt. of Bihar. <br>
<br>
We impart Teaching from Std. 1 to Std. 10 strictly according to the new syllabus introduced by Central Board of Secondary Education (C.B.S.E) pattern. New Delhi accordingly we not only believe in developing a Child in the field of academics but also create ample opportunities for full personality development which does not change even in the world of rapid change. At the same time great stress is provided on character building developing culture tradition, Indian values system and ethos etc.
 <br>
<br>
I opine hat education school be both rigorous and an enjoyable process for the children. They are encouraged to learn for themselves under a teacher's guidance. We don't prepare the life In conclusion, I express my sincere gratitude's to the Patrons, Benefactors, Teaching members of the school whose constructive suggestion and co- operation never be forgotten and above all the parents who have interested the future of the children to us.
</p>
	<p>&nbsp;</p>
    </div>

<div class="col-sm-3">
	<div class="col-md-12" style="padding:0;">
		<?php echo $__env->make('includes.latest_news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldSection(); ?>
	</div>

<div class="clearfix">&nbsp;</div>
</div>
<div class="clearfix">&nbsp;</div>
</div>

  </div>


            <!-- FOOTER -->

            <footer>
                <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->yieldSection(); ?>
            </footer>



        </div><!-- /.container -->
        
        <?php echo $__env->make('includes.js_part', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldSection(); ?>

    </body>

</html>